<?php
error_reporting(E_PARSE);
include '../library/configServer.php';
include '../library/consulSQL.php';
session_start();
$suma = 0;
if(isset($_GET['precio'])){

    $existencia = 0;
    $pedido = 0;
    for($i = 0;$i< $_SESSION['contador'];$i++){
        $consulta=ejecutarSQL::consultar("select * from producto where CodigoProd='".$_SESSION['producto'][$i]."'");
        while($fila = mysqli_fetch_array($consulta)) {
            if($fila['CodigoProd']==$_GET['precio']){
                $pedido++;
            }
        }
    }
    $consulta=ejecutarSQL::consultar("select * from producto where CodigoProd='".$_GET['precio']."'");
    while($fila = mysqli_fetch_array($consulta)) {
        $existencia = $fila['Stock'];
    }
    
    if(($pedido+1)<=$existencia){
    $_SESSION['producto'][$_SESSION['contador']] = $_GET['precio'];
    
    
    $_SESSION['contador']++;
    echo "<script>$('.modal-carrito').modal('show');</script>";
    }else{
        echo "<script>$('.modal-existencia').modal('show');</script>";
    }
}
echo '<table class="table table-bordered">';
for($i = 0;$i< $_SESSION['contador'];$i++){
    $consulta=ejecutarSQL::consultar("select * from producto where CodigoProd='".$_SESSION['producto'][$i]."'");
    while($fila = mysqli_fetch_array($consulta)) {
            echo "<tr><td>".$fila['NombreProd']."</td><td> ".$fila['Precio']."</td></tr>";
    $suma += $fila['Precio'];
    }
}
echo "<tr><td>Subtotal</td><td>$".number_format($suma,2)."</td></tr>";
echo "</table>";

$_SESSION['sumaTotal']=$suma;