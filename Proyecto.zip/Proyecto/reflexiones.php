<!DOCTYPE html>
<html lang="es">
<head>
    <title>Reflexiones</title>
    <?php include './inc/link.php'; ?>
</head>
<body id="container-page-index">
    <?php include './inc/navbar.php'; ?>
    <div class="jumbotron" id="jumbotron-index">
      <h1><span class="tittles-pages-logo">Salesianos Don Bosco</span> <small style="color: #fff;"></small></h1>
      <p>
         El Evangelio Hoy es el evangelio para cada día de la semana, es una reflexión corta, explicada de la palabra de Dios. Un versículo biblico diario o una porción de las escrituras para meditar cada día del año. ¿Qué es predicar el Evangelio? Contesto que predicar el evangelio es exaltar a Jesucristo. Tal vez ésta sea la mejor respuesta que puedo ofrecer. Me entristece comprobar a menudo cuán poco se entiende el Evangelio, aun entre algunos de los mejores cristianos.


      </p>
    </div>
    <section id="new-prod-index">
         <div class="container">
            <div class="page-header">
                <h1>Reflexiones <br><small>Con todo mi corazón te he buscado; No me dejes desviarme de tus mandamientos. En mi corazón he guardado tus dichos, Para no pecar contra ti. Bendito tú, oh Jehová; Enséñame tus estatutos. Con mis labios he contado todos los juicios de tu boca.

Me he gozado en el camino de tus testimonios más que de toda riqueza. En tus mandamientos meditaré; Consideraré tus caminos. Me regocijaré en tus estatutos; No me olvidaré de tus palabras. Salmo 119:9-16 <br> La Fortaleza de Dios

<br>

Isaías 41:10

Dios tiene una enorme reserva de poder con la cual cumplir la promesa de hoy, porque él es capaz de hacer todas las cosas. Querido creyente, no tienes nada que temer mientras no puedas drenar por completo el océano de la omnipotencia de Dios ni derribar las imponentes montañas de su increíble fuerza y hacerlas pedazos. Jamás pienses que la fuerza humana será capaz de superar el poder de Dios.
<br>

Mientras los cimientos del planeta permanezcan tienes suficientes razones para permanecer firme en tu fe. El mismo Dios que mantiene a la tierra en su órbita, que aviva la llama del sol y que enciende las estrelladas lumbreras de la noche ha prometido suplirte de fuerzas cada día. Dado que él es plenamente capaz de sustentar el universo, jamás te imagines que será incapaz de cumplir sus propias promesas.
<br>

Recuerda lo que hizo en los días de antaño con las generaciones anteriores. Recuerda cómo él habló y fue hecho, cómo él dio la orden y la creación cobró vida. ¿Acaso perderá su poder el que creó el mundo? ¿El que colgó el mundo de la nada de repente será incapaz de sostener a sus hijos? ¿Será infiel a su Palabra por falta de poder? ¿Quién es el que controla las tormentas porque hace «de las nubes [sus] carros de guerra.
<br>

¡[Él cabalga] en las alas del viento!» (Salmo 104:3) y tiene a los océanos en «la palma de su mano» (Isaías 40:12)? ¿Cómo podría él fallarte? Si es que puso una promesa de fe como esa en su Palabra, ¿creerás siquiera por un momento que él podría haberse excedido diciendo algo que no fuera capaz de cumplir con su poder? ¡De ninguna manera! ¡Ya no dudes más!

<br>

Oh, mi Dios y mi fortaleza, sé que tu promesa se cumplirá porque la reserva inagotable de tu gracia jamás podrá agotarse, tus amigos jamás podrán vaciar la sobreabundante provisión de tu fortaleza ni tus enemigos la podrán saquear. </small></h1>
            </div>
            <div class="row">
              <?php
                  include 'library/configServer.php';
                  include 'library/consulSQL.php';
                  $consulta= ejecutarSQL::consultar("select * from producto where Stock > 0 limit 6");
                  $totalproductos = mysqli_num_rows($consulta);
                  if($totalproductos>0){
                      while($fila=mysqli_fetch_array($consulta)){
                         echo '
                        <div class="col-xs-12 col-sm-6 col-md-4">
                             <div class="thumbnail">
                               <img src="assets/img-products/'.$fila['Imagen'].'">
                               <div class="caption">
                                 <h3>'.$fila['Marca'].'</h3>
                                 <p>'.$fila['NombreProd'].'</p>
                                 <p>$'.$fila['Precio'].'</p>
                                 <p class="text-center">
                                     <a href="infoProd.php?CodigoProd='.$fila['CodigoProd'].'" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i>&nbsp; Detalles</a>&nbsp;&nbsp;
                                     <button value="'.$fila['CodigoProd'].'" class="btn btn-success btn-sm botonCarrito"><i class="fa fa-shopping-cart"></i>&nbsp; Añadir</button>
                                 </p>

                               </div>
                             </div>
                         </div>     
                         ';
                     }   
                  }else{
                      echo '<h2>No hay productos registrados en la tienda</h2>';
                  }  
              ?>  
            </div>
         </div>
    </section>
    <section id="reg-info-index">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 text-center">
                   <article style="margin-top:20%;">
                        <p><i class="fa fa-users fa-4x"></i></p>
                        <h3>Registrate</h3>
                        <p>Registrese y hagase cliente de <span class="tittles-pages-logo"></span> para recibir las mejores ofertas y descuentos especiales de nuestros productos.</p>
                        <p><a href="registration.php" class="btn btn-info btn-block">Registrarse</a></p>   
                   </article>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <img src="assets/img/Libro9.jpg" alt="Smart-TV" class="img-responsive">
                </div>
            </div>
        </div>
    </section>
    <section id="distribuidores-index">
        <div class="container">
            <div class="col-xs-12 col-sm-6">

            </div>
            <div class="col-xs-12 col-sm-6">

            </div>
            <div class="col-xs-12">
                <div class="page-header">
                  <h1>Seguimos a Jesús <small style="color: #333;">Pan diario de la Palabra de Dios</small></h1>
                </div>
                <br><br>
                <br>
                 <img src="assets/img/1poster.jpg" alt="logos-marcas" class="img-responsive">
                 <br>
                 <br>
                  <img src="assets/img/fal.png" alt="logos-marcas" class="img-responsive">
            </div>
        </div>
    </section>
    <?php include './inc/footer.php'; ?>
</body>
</html>